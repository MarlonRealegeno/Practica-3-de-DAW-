window.onload = function (){
    const submit = document.getElementById("submit");
    submit.addEventListener('click', validate);
}

function validate(){
    const cardnumber = document.getElementById("carnumber");
    const errorcard= document.getElementById("errorcardnumber");
    expcard=/^(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13}|6(?:011|5[0-9][0-9])[0-9]{12})$/im;

    const month = document.getElementById("Month");
    const errormes = document.getElementById("errormonth");
    monthcard=/^0[123456789]{1,2}$|10|11|12$/;

    const year = document.getElementById("Year");
    const erroryearr =document.getElementById("erroryear");
    yearcard=/^20[23][0-9]$/;

    const pass = document.getElementById("ccv");
    const errorpass =document.getElementById("errorccv");
    passcard=/[0-9]{3}/;

    const nombre =document.getElementById("name");
    const errornombre= document.getElementById("errorname");
    namecard=/^(?:[a-zA-Z]+\.?\s)+[a-zA-Z]+/;


    //If que valido el mes
    if (!month.value){
        errormes.classList.add("visible");
        month.classList.add("invalid");
        msj="Ingrese un Mes del Año"
        errormes.innerHTML=msj;
    }
    else if(!monthcard.test(month.value)){
        errormes.classList.add("visible");
        month.classList.add("invalid");
        msj="Ingrese un mes correcto"
        errormes.innerHTML=msj;
    }
    else{
        errormes.classList.remove("visible");
        month.classList.remove("invalid");
    }


    //if que valida el Año
    if (!year.value){
        erroryearr.classList.add("visible");
        year.classList.add("invalid");
        msj="Ingrese el Año"
        erroryearr.innerHTML=msj;
    }
    else if(!yearcard.test(year.value)){
        erroryearr.classList.add("visible");
        month.classList.add("invalid");
        msj="Ingrese un Año Valido"
        erroryearr.innerHTML=msj;
    }
    else{
        erroryearr.classList.remove("visible");
        year.classList.remove("invalid");
    }
    //If validador de CCV
    if (!pass.value){
        errorpass.classList.add("visible");
        pass.classList.add("invalid");
        msj="Ingrese un Codigo"
        errorpass.innerHTML=msj;
    }
    else if(!passcard.test(pass.value)){
        errorpass.classList.add("visible");
        pass.classList.add("invalid");
        msj="Ingrese el Codigo Valido"
        errorpass.innerHTML=msj;
    }
    else{
        errorpass.classList.remove("visible");
        pass.classList.remove("invalid");
    }

    //validad la tarjeta de Credito
    if(!cardnumber.value){
        errorcard.classList.add("visible");
        cardnumber.classList.add("invalid");
        msj="Ingrese numero de tarjeta"
        errorcard.innerHTML=msj;
    }else if(!expcard.test(cardnumber.value)){
        errorcard.classList.add("visible");
        cardnumber.classList.add("invalid");
        msj="Numero de tarjeta, tiene formato invalido , revise que no tenga guiones"
        errorcard.innerHTML=msj;
    }
    else{
        errorcard.classList.remove("visible");
        cardnumber.classList.remove("invalid");
    }

    //validacion de nombre
    if(!nombre.value){
        errornombre.classList.add("visible");
        nombre.classList.add("invalid");
        msj="Ingrese un nombre"
        errornombre.innerHTML=msj;
    }else if(!namecard.test(nombre.value)){
        errornombre.classList.add("visible");
        nombre.classList.add("invalid");
        msj="Ingrese un nombre valido"
        errornombre.innerHTML=msj;
    }
    else{
        errornombre.classList.remove("visible");
        nombre.classList.remove("invalid");
    }


}